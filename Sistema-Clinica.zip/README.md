# Sistema-Clinica
Projeto para a matéria Estrutura dos Dados 1, um sistema simples para uma clínica utilizando as estruturas básicas dos Dados (stack,qeue,list)
This is just a simples college project for a subject, there's are no intention of using this repository as a professional source, but you
can use to study as much as you can!

Warning: Probably the main Language on it will be Portuguese.
