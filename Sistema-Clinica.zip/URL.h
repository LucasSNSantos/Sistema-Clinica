#ifndef ARQUIVOS_URL_H
#define ARQUIVOS_URL_H

char URLatendimento[] = "Arquivos/atendidos.txt";


#endif
